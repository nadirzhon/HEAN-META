# Руководство по настройке Bybit интеграции

## Быстрый старт

### 1. Получение API ключей

#### Для testnet (рекомендуется сначала):
1. Зайдите на https://testnet.bybit.com/
2. Зарегистрируйтесь или войдите
3. Перейдите в API Management
4. Создайте новый API ключ
5. Установите права: **только торговля** (не вывод средств!)
6. Сохраните API Key и Secret Key

#### Для mainnet:
1. Зайдите на https://www.bybit.com/
2. Перейдите в API Management
3. Создайте новый API ключ
4. Установите права: **только торговля**
5. Настройте IP whitelist (рекомендуется)
6. Сохраните API Key и Secret Key

### 2. Настройка .env файла

Добавьте в файл `.env`:

```bash
# Bybit API credentials
BYBIT_API_KEY=your-api-key-here
BYBIT_API_SECRET=your-api-secret-here

# Testnet или mainnet
BYBIT_TESTNET=true  # true для testnet, false для mainnet

# Для live trading (обязательно!)
LIVE_CONFIRM=YES
TRADING_MODE=live
```

### 3. Тестирование подключения

```bash
# Установите зависимости (если еще не установлены)
pip install websockets

# Протестируйте подключение
python test_bybit_connection.py
```

Ожидаемый вывод:
```
✅ Connected successfully
✅ API connection test passed
✅ Order placement test passed
✅ WebSocket test completed
✅ All tests passed!
```

### 4. Запуск системы

```bash
# Запуск в live режиме с Bybit
python -m hean.main run
```

## Проверка работы

### Логи подключения:

Вы должны увидеть:
```
[INFO] Bybit HTTP client connected to testnet
[INFO] Bybit public WebSocket connected to testnet
[INFO] Bybit private WebSocket connected to testnet
[INFO] Subscribed to ticker for BTCUSDT
[INFO] Subscribed to ticker for ETHUSDT
[INFO] Subscribed to order updates
[INFO] Subscribed to position updates
[INFO] Subscribed to execution updates
```

### Проверка данных:

Система должна получать:
- ✅ Тики в реальном времени
- ✅ Funding rates каждые 8 часов
- ✅ Обновления ордеров
- ✅ Обновления позиций

## Безопасность

### ⚠️ ВАЖНО:

1. **Никогда не давайте права на вывод средств** API ключам
2. **Используйте IP whitelist** на mainnet
3. **Тестируйте на testnet** перед mainnet
4. **Начните с минимального капитала**
5. **Мониторьте первые сделки**

### Рекомендуемые настройки API ключа:

- ✅ Разрешить: Trading
- ❌ Запретить: Withdraw, Transfer, Deposit
- ✅ IP Whitelist: ваш IP адрес (для mainnet)

## Troubleshooting

### Проблема: "Bybit API credentials not configured"

**Решение**: Проверьте, что в `.env` файле установлены:
- `BYBIT_API_KEY`
- `BYBIT_API_SECRET`

### Проблема: "Authentication failed"

**Решение**:
1. Проверьте правильность API ключей
2. Убедитесь, что ключи не истекли
3. Проверьте права доступа ключей

### Проблема: "WebSocket connection closed"

**Решение**:
- Система автоматически переподключается
- Проверьте интернет соединение
- Проверьте, не заблокирован ли WebSocket файрволом

### Проблема: "Order rejected"

**Решение**:
1. Проверьте баланс на аккаунте
2. Проверьте минимальный размер ордера
3. Проверьте права API ключа
4. Проверьте, что символ поддерживается

## Переход с testnet на mainnet

### Шаги:

1. **Протестируйте на testnet минимум 1 неделю**
2. **Убедитесь, что все работает стабильно**
3. **Получите mainnet API ключи**
4. **Обновите .env**:
   ```bash
   BYBIT_TESTNET=false
   BYBIT_API_KEY=mainnet-key
   BYBIT_API_SECRET=mainnet-secret
   ```
5. **Начните с минимального капитала**
6. **Мониторьте внимательно**

## Мониторинг

### Что отслеживать:

1. **Подключения**:
   - HTTP клиент подключен
   - WebSocket клиенты подключены
   - Подписки активны

2. **Исполнение**:
   - Ордера размещаются успешно
   - Заполнения происходят
   - Позиции открываются/закрываются

3. **Ошибки**:
   - Количество ошибок подключения
   - Количество отклоненных ордеров
   - Проблемы с синхронизацией

## Готово!

Интеграция с Bybit полностью завершена и готова к использованию. 

Просто настройте API ключи и запустите систему! 🚀

