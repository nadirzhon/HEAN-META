# Чеклист для запуска проекта HEAN

## ✅ Что уже готово

- ✅ Python 3.11.5 установлен (требуется >=3.11)
- ✅ Основные зависимости установлены (pydantic, aiohttp, websockets, httpx)
- ✅ Файл `.env` существует
- ✅ Структура проекта на месте

## 📋 Что нужно сделать перед запуском

### 1. Установить проект в режиме разработки

```bash
# Установить все зависимости (включая dev)
make install

# Или вручную:
pip install -e ".[dev]"
```

**Проверка:**
```bash
pip show hean
# Должно показать, что пакет установлен в editable mode
```

### 2. Проверить/настроить `.env` файл

Файл `.env` уже существует, но убедитесь, что в нем настроены необходимые параметры:

**Минимальная конфигурация для paper trading:**
```env
TRADING_MODE=paper
INITIAL_CAPITAL=400.0
```

**Для live trading (требуются API ключи Bybit):**
```env
TRADING_MODE=live
LIVE_CONFIRM=YES
BYBIT_API_KEY=your-key
BYBIT_API_SECRET=your-secret
BYBIT_TESTNET=true  # или false для mainnet
```

### 3. Опционально: Установить LLM зависимости

Если планируете использовать генерацию агентов или систему автоулучшений:

```bash
pip install -e ".[llm]"
```

И добавить в `.env`:
```env
OPENAI_API_KEY=your-key
# или
ANTHROPIC_API_KEY=your-key
```

### 4. Проверить Docker (если используете)

```bash
# Проверить, что Docker установлен
docker --version
docker-compose --version
```

## 🚀 Запуск проекта

### Вариант 1: Локальный запуск

```bash
# Установить зависимости (если еще не установлены)
make install

# Запустить систему
make run

# Или напрямую:
python -m hean.main run
```

### Вариант 2: Запуск через Docker

```bash
# Собрать и запустить
make docker-run

# Или вручную:
docker-compose up -d

# Просмотр логов
make docker-logs
# или
docker-compose logs -f
```

## 🔍 Проверка работоспособности

### 1. Проверить, что система запускается

```bash
python -m hean.main run
```

Должны увидеть:
- Логи запуска системы
- Статус каждые 10 секунд (equity, daily PnL, drawdown)
- Работающие стратегии в paper mode

### 2. Проверить health endpoint

```bash
curl http://localhost:8080/health
```

Должен вернуть статус 200 OK.

### 3. Запустить тесты

```bash
make test
# или
pytest
```

## 📝 Дополнительные настройки

### Для backtesting:

```bash
# Запустить бэктест на 30 дней
python -m hean.main backtest --days 30
```

### Для генерации агентов:

```bash
# Установить LLM зависимости
pip install -e ".[llm]"

# Настроить API ключ
export OPENAI_API_KEY="your-key"

# Сгенерировать агента
python generate_agent.py initial -o my_agent.py
```

### Для Process Factory (экспериментально):

```env
PROCESS_FACTORY_ENABLED=true
```

## ⚠️ Важные замечания

1. **Безопасность:**
   - По умолчанию система работает в `paper` режиме (безопасно)
   - Для live trading требуется явно установить `LIVE_CONFIRM=YES`
   - Начните с testnet: `BYBIT_TESTNET=true`

2. **Зависимости:**
   - Убедитесь, что установлены все зависимости через `make install`
   - Пакет должен быть установлен в editable mode для разработки

3. **Логи:**
   - Логи сохраняются в директории `logs/`
   - Уровень логирования настраивается через `LOG_LEVEL` в `.env`

4. **Порты:**
   - Health check endpoint: `http://localhost:8080/health`
   - Убедитесь, что порт 8080 свободен

## 🐛 Решение проблем

### Проблема: "ModuleNotFoundError: No module named 'hean'"

**Решение:**
```bash
# Установить проект в editable mode
pip install -e ".[dev]"
```

### Проблема: "ValueError: Live trading requires LIVE_CONFIRM=YES"

**Решение:**
- Это нормально для paper trading
- Если нужен live trading, добавьте `LIVE_CONFIRM=YES` в `.env`

### Проблема: "Port 8080 already in use"

**Решение:**
- Измените `HEALTH_CHECK_PORT` в `.env`
- Или остановите процесс, использующий порт 8080

### Проблема: Docker не запускается

**Решение:**
```bash
# Проверить логи
docker-compose logs

# Пересобрать образ
docker-compose build --no-cache

# Очистить и перезапустить
docker-compose down -v
docker-compose up -d
```

## ✅ Финальная проверка

Перед первым запуском убедитесь:

- [ ] Python 3.11+ установлен
- [ ] Проект установлен через `make install`
- [ ] Файл `.env` настроен
- [ ] Порт 8080 свободен (если используете health check)
- [ ] Для live trading: API ключи Bybit настроены
- [ ] Для LLM функций: API ключи OpenAI/Anthropic настроены (опционально)

## 🎯 Быстрый старт (TL;DR)

```bash
# 1. Установить зависимости
make install

# 2. Проверить .env (уже существует, но можно настроить)

# 3. Запустить
make run
```

Готово! Система должна запуститься в paper trading режиме.

