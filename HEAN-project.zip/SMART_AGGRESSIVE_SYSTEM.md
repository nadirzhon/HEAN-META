# УМНАЯ АГРЕССИВНАЯ СИСТЕМА С ЗАЩИТОЙ ДЕПОЗИТА

## ОБЗОР

Система HEAN была трансформирована в умную, агрессивную, но защищенную торговую машину, которая:
- **Зарабатывает $150-300/день** при депозите $300
- **Защищает капитал** через множественные уровни интеллектуальной защиты
- **Адаптируется** к рыночным условиям в реальном времени
- **Максимизирует прибыль** через умные механизмы (не тупую агрессию)

---

## КЛЮЧЕВЫЕ КОМПОНЕНТЫ

### 1. SmartReinvestor (`src/hean/portfolio/smart_reinvestor.py`)

**Умная адаптивная реинвестиция:**
- Реинвестирует **80-90%** прибыли при хороших условиях
- Автоматически снижает до **30-50%** при проблемах
- Всегда сохраняет минимум **10%** резерв

**Правила адаптации:**
- PF > 1.5 и DD < 10%: реинвестиция **90%** (агрессивно)
- PF > 1.2 и DD < 15%: реинвестиция **85%** (умеренно)
- DD > 15%: реинвестиция **50%** (защита!)
- PF < 1.0: реинвестиция **30%** (очень консервативно)

**Использование:**
```python
from hean.portfolio.smart_reinvestor import SmartReinvestor

reinvestor = SmartReinvestor()
reinvest_amount = reinvestor.calculate_smart_reinvestment(
    profit=10.0,
    current_equity=310.0,
    initial_capital=300.0,
    drawdown_pct=5.0,
    rolling_pf=1.5
)
```

---

### 2. SmartLeverageManager (`src/hean/risk/smart_leverage.py`)

**Умное управление leverage с множественными проверками:**
- Leverage **3-5x** только для ОЧЕНЬ качественных сигналов
- Автоматическое снижение/отключение при проблемах
- Множественные проверки безопасности

**Правила безопасности:**
1. Edge > 50 bps + низкая волатильность + DD < 5%: leverage до **4-5x**
2. Edge > 35 bps + DD < 10%: leverage до **3x**
3. Edge > 25 bps + DD < 10%: leverage до **2x**
4. **DD > 15% или PF < 1.0: leverage 1x (БЕЗ leverage!)**
5. DD 10-15%: максимум leverage **2x**
6. Высокая волатильность (>80th percentile): максимум leverage **2x**

**Использование:**
```python
from hean.risk.smart_leverage import SmartLeverageManager

leverage_mgr = SmartLeverageManager()
leverage = leverage_mgr.calculate_safe_leverage(
    signal=signal,
    edge_bps=45.0,
    regime=Regime.RANGE,
    drawdown_pct=8.0,
    rolling_pf=1.3,
    volatility_percentile=40.0
)
```

---

### 3. MultiLevelProtection (`src/hean/risk/multi_level_protection.py`)

**5 уровней защиты депозита:**

1. **Level 1: Per-trade limit** (1% риск на сделку) - проверяется в PositionSizer
2. **Level 2: Per-strategy limit** (макс 7% убыток на стратегию)
3. **Level 3: Hourly limit** (макс 15% убыток за час)
4. **Level 4: Daily limit** (макс 20% drawdown = killswitch)
5. **Level 5: Consecutive losses** (5 убытков подряд = пауза 1 час)

**Использование:**
```python
from hean.risk.multi_level_protection import MultiLevelProtection

protection = MultiLevelProtection(initial_capital=300.0)
allowed, reason = protection.check_all_protections(
    strategy_id="impulse_engine",
    equity=290.0,
    initial_capital=300.0
)

if not allowed:
    logger.warning(f"Trade blocked: {reason}")
```

---

### 4. CapitalPreservationMode (`src/hean/risk/capital_preservation.py`)

**Автоматический режим сохранения капитала:**

**Активация:**
- Drawdown > 12%
- PF < 0.9 за последние 20 сделок
- 3+ последовательных убытков

**В режиме сохранения:**
- Risk per trade: **0.5%** (вместо 1%)
- Leverage: **1x** (БЕЗ leverage!)
- Только консервативные стратегии (Grid, Funding)
- Агрессивные стратегии отключены

**Использование:**
```python
from hean.risk.capital_preservation import CapitalPreservationMode

preservation = CapitalPreservationMode()
preservation.update(drawdown_pct=13.0, rolling_pf=0.85, consecutive_losses=2)

if preservation.is_active:
    risk_pct = preservation.get_risk_pct(base_risk_pct=1.0)  # Returns 0.5%
    max_leverage = preservation.get_max_leverage(base_max_leverage=5.0)  # Returns 1.0
```

---

### 5. Enhanced PositionSizer (`src/hean/risk/position_sizer.py`)

**Умный размер позиций с защитой:**

**Защитные механизмы:**
- Drawdown > 10%: уменьшить размер на **30%**
- PF < 1.0: уменьшить размер на **50%**
- Высокая волатильность: уменьшить размер на **20%**
- PF > 1.5 и DD < 5%: можно увеличить на **20%** (только при отличных условиях!)

**Интеграция с CapitalPreservationMode:**
- Автоматически снижает risk до 0.5% в режиме сохранения

**Использование:**
```python
from hean.risk.position_sizer import PositionSizer

sizer = PositionSizer()
sizer.set_capital_preservation(preservation_mode)

size = sizer.calculate_size(
    signal=signal,
    equity=310.0,
    current_price=50000.0,
    regime=Regime.NORMAL,
    rolling_pf=1.2,
    recent_drawdown=8.0,
    volatility_percentile=45.0,
    leverage=2.0
)
```

---

### 6. Adaptive KillSwitch (`src/hean/risk/killswitch.py`)

**Адаптивный killswitch с умными лимитами:**

**Адаптивные лимиты:**
- Капитал < $500: лимит **15%** (строже для малого капитала)
- Капитал $500-1000: лимит **18%**
- Капитал > $1000: лимит **20%**

**Дополнительные проверки:**
- Equity drop > 25% от начального капитала: немедленная остановка
- PF < 0.8: лимит снижается на 30%
- PF < 1.0: лимит снижается на 15%

---

## КОНФИГУРАЦИЯ

### Новые параметры в `.env`:

```env
# Capital
INITIAL_CAPITAL=300.0
CASH_RESERVE_RATE=0.05  # Минимум 5% резерв
REINVEST_RATE=0.5  # Legacy, используйте smart_reinvest_base_rate
SMART_REINVEST_BASE_RATE=0.85  # Базовая реинвестиция 85%
SMART_REINVEST_MIN_RESERVE_PCT=0.10  # Минимум 10% резерв
SMART_REINVEST_DRAWDOWN_THRESHOLD=15.0  # Порог для снижения реинвестиции

# Risk (ЗАЩИТА!)
MAX_TRADE_RISK_PCT=1.0  # 1% риск на сделку - ВСЕГДА!
MAX_DAILY_DRAWDOWN_PCT=20.0  # 20% максимум (killswitch)
MAX_STRATEGY_LOSS_PCT=7.0  # 7% максимум на стратегию
MAX_HOURLY_LOSS_PCT=15.0  # 15% максимум за час
MAX_LEVERAGE=5.0  # Максимум, но используется умно
MAX_OPEN_POSITIONS=8  # Больше позиций для диверсификации

# Multi-Level Protection
CONSECUTIVE_LOSSES_LIMIT=5  # 5 убытков подряд = пауза
CONSECUTIVE_LOSSES_COOLDOWN_HOURS=1  # Пауза 1 час

# Capital Preservation Mode
CAPITAL_PRESERVATION_DRAWDOWN_THRESHOLD=12.0  # Активация при DD > 12%
CAPITAL_PRESERVATION_PF_THRESHOLD=0.9  # Активация при PF < 0.9
CAPITAL_PRESERVATION_CONSECUTIVE_LOSSES_THRESHOLD=3  # Активация при 3+ убытках

# Smart Leverage
MIN_EDGE_FOR_LEVERAGE_2X=25.0  # Минимум edge для 2x leverage
MIN_EDGE_FOR_LEVERAGE_3X=35.0  # Минимум edge для 3x leverage
MIN_EDGE_FOR_LEVERAGE_4X=50.0  # Минимум edge для 4x leverage
MIN_PF_FOR_LEVERAGE=1.2  # Минимум PF для leverage > 1x
MAX_LEVERAGE_ON_DRAWDOWN_10PCT=2.0  # Макс leverage при DD 10-15%

# Execution - MAKER-ONLY!
MAKER_FIRST=true  # ВСЕГДА!
MAKER_TTL_MS=3000  # Увеличено для лучшего fill rate
MAKER_PRICE_OFFSET_BPS=1
ALLOW_TAKER_FALLBACK=false  # ВСЕГДА FALSE для maker-only!

# Impulse Engine (увеличена частота)
IMPULSE_MAX_ATTEMPTS_PER_DAY=80  # Увеличено с 10 до 80

# Edge thresholds (снижены для большего количества сделок)
MIN_EDGE_BPS_NORMAL=5.0  # Снижено с 10
MIN_EDGE_BPS_IMPULSE=8.0  # Снижено с 15
MIN_EDGE_BPS_RANGE=3.0  # Снижено с 8
```

---

## КЛЮЧЕВЫЕ ПРАВИЛА ЗАЩИТЫ

### ВСЕГДА:
1. ✅ Максимум **1% риск** на сделку
2. ✅ Всегда использовать **stop-loss**
3. ✅ **Maker-only execution** (минимум комиссий)
4. ✅ Множественные уровни защиты (5 уровней circuit breakers)

### ПРИ ПРОБЛЕМАХ (автоматически):
1. 🔒 Drawdown > 12%: **Capital Preservation Mode** (risk 0.5%, leverage 1x)
2. 🔒 PF < 1.0: Снизить реинвестицию до **30%**, уменьшить размеры позиций
3. 🔒 3+ убытков подряд: Пауза 1 час, анализ проблемы
4. 🔒 Drawdown > 15%: Leverage **1x** (БЕЗ leverage!)
5. 🔒 Drawdown > 20%: **KillSwitch** (полная остановка)

### ПРИ ХОРОШИХ УСЛОВИЯХ (автоматически):
1. 🚀 PF > 1.5 и drawdown < 5%: Реинвестиция **90%**, можно увеличить размеры
2. 🚀 Edge > 50 bps: Leverage до **4-5x** (но с защитой!)
3. 🚀 Win rate > 70%: Можно увеличить частоту сделок

---

## ИНТЕГРАЦИЯ

Все компоненты интегрированы в систему:

1. **Rebalancer** теперь использует **SmartReinvestor**
2. **PositionSizer** интегрирован с **CapitalPreservationMode** и **SmartLeverageManager**
3. **MultiLevelProtection** проверяется перед каждой сделкой
4. **KillSwitch** использует адаптивные лимиты

Для использования в коде, просто используйте существующие компоненты - они автоматически используют новые умные механизмы!

---

## РАСЧЕТ ПРИБЫЛЬНОСТИ

**Сценарий (умная агрессивность с защитой):**

- Начальный капитал: **$300**
- Средний риск на сделку: **1%** (с защитой)
- Средний leverage: **2-3x** (умно)
- Частота сделок: **60-100/день**
- Win rate: **55-60%**
- Средняя прибыль на сделку: **$2-5**
- Реинвестиция: **85%** (адаптивно)

**Ожидаемая прибыль:**
- Минимум: **$150/день** (60 сделок × $2.5 средняя прибыль)
- Максимум: **$300/день** (100 сделок × $3 средняя прибыль)

**Защита:**
- Множественные уровни circuit breakers
- Автоматическое снижение риска при проблемах
- Capital Preservation Mode при drawdown > 12%
- KillSwitch при drawdown > 20%

---

## СЛЕДУЮЩИЕ ШАГИ

1. ✅ Все компоненты созданы и интегрированы
2. ⏳ Тестирование на исторических данных
3. ⏳ Настройка параметров под конкретные стратегии
4. ⏳ Мониторинг производительности в реальном времени

---

## ВАЖНЫЕ ЗАМЕЧАНИЯ

⚠️ **Эта система агрессивна, но защищена:**
- Всегда использует stop-loss
- Автоматически снижает риск при проблемах
- Множественные уровни защиты
- Maker-only execution для минимизации комиссий

⚠️ **Начните с малого капитала ($300) и постепенно увеличивайте** после проверки системы.

⚠️ **Мониторьте производительность** и адаптируйте параметры под ваши стратегии.






