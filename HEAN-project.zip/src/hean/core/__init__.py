"""Core event-driven infrastructure."""
