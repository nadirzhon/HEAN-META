"""Readiness evaluation module."""
