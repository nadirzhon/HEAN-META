"""Bybit exchange integration."""
