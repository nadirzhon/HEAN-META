"""Built-in process definitions."""

__all__ = [
    "get_process_definition",
    "list_builtin_processes",
]

