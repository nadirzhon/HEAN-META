"""Risk management module."""
