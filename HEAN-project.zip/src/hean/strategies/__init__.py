"""Trading strategies module."""
