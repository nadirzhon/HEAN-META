# HEAN Website

Адаптивный веб-сайт для проекта HEAN - Production-grade event-driven crypto trading research system.

## Структура файлов

```
web/
├── index.html      # Основная HTML страница
├── styles.css      # Стили с адаптивным дизайном
├── script.js       # JavaScript для интерактивности
└── README.md       # Этот файл
```

## Особенности

- ✅ Полностью адаптивный дизайн (mobile-first)
- ✅ Современный UI с градиентами и анимациями
- ✅ Плавная прокрутка и навигация
- ✅ Интерактивные элементы (копирование кода, ripple эффекты)
- ✅ Оптимизация производительности (lazy loading, intersection observer)
- ✅ Темная тема, соответствующая стилю проекта
- ✅ Анимации при прокрутке страницы

## Как использовать

### 🐳 Запуск через Docker (Рекомендуется)

#### Вариант 1: Используя docker-compose из корня проекта

```bash
# Из корня проекта HEAN
docker-compose up -d web

# Сайт будет доступен на http://localhost:3000
```

#### Вариант 2: Используя docker-compose в папке web

```bash
# Из папки web/
docker-compose up -d

# Сайт будет доступен на http://localhost:3000
```

#### Вариант 3: Используя скрипт start.sh

```bash
# Из папки web/
./start.sh

# Сайт будет доступен на http://localhost:3000
```

#### Вариант 4: Ручная сборка и запуск

```bash
# Из папки web/
docker build -t hean-website .
docker run -d -p 3000:80 --name hean-website hean-website

# Сайт будет доступен на http://localhost:3000
```

#### Управление контейнером

```bash
# Просмотр логов
docker logs -f hean-website

# Остановка
docker stop hean-website

# Запуск
docker start hean-website

# Удаление
docker rm -f hean-website
```

### 💻 Локальный просмотр (без Docker)

Просто откройте `index.html` в браузере:

```bash
# В папке web/
open index.html
# или
python -m http.server 8000
# затем откройте http://localhost:8000
```

### 🌐 Развертывание

Вы можете развернуть сайт на любом статическом хостинге:

- **GitHub Pages**: Просто загрузите папку `web/` в репозиторий
- **Netlify**: Перетащите папку `web/` в Netlify
- **Vercel**: Используйте команду `vercel deploy web/`
- **Любой веб-сервер**: Скопируйте файлы в директорию веб-сервера
- **Docker**: Используйте созданный Dockerfile для развертывания на любом Docker-хостинге

### Настройка

Вы можете настроить:

1. **Цвета**: Измените CSS переменные в `styles.css` (секция `:root`)
2. **Контент**: Отредактируйте `index.html`
3. **Анимации**: Настройте в `script.js` и `styles.css`

## Секции сайта

1. **Hero** - Главный экран с описанием проекта
2. **Features** - Основные возможности системы
3. **Strategies** - Описание торговых стратегий
4. **Architecture** - Архитектура системы
5. **Quick Start** - Инструкции по быстрому старту
6. **Documentation** - Ссылки на документацию
7. **Safety** - Важные замечания по безопасности

## Браузерная поддержка

- Chrome/Edge (последние версии)
- Firefox (последние версии)
- Safari (последние версии)
- Mobile browsers (iOS Safari, Chrome Mobile)

## Производительность

- Минимальные зависимости (только Google Fonts)
- Оптимизированные CSS анимации
- Lazy loading для изображений
- Intersection Observer для анимаций при прокрутке

## Лицензия

MIT License - как и основной проект HEAN

