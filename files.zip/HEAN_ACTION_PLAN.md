# HEAN — Action Plan: Как что исправить

## ПОРЯДОК РАБОТ

Приоритет определён по формуле: **Риск потери × Вероятность × Сложность фикса**

---

## НЕДЕЛЯ 1: Критические баги (без них нельзя торговать)

---

### FIX-001: Двойной PnL (BUG-001)
**Приоритет:** P0 — СЕЙЧАС
**Время:** 15 минут
**Файл:** `src/hean/main.py`

**Проблема:** `record_realized_pnl` вызывается в `_close_position_at_price()` И в `_handle_position_closed()`.

**Решение:** Удалить вызов из `_close_position_at_price()`. Оставить ТОЛЬКО в `_handle_position_closed()` — он вызывается через EVENT и является единственной правильной точкой учёта.

```python
# Файл: main.py, функция _close_position_at_price (~строка 2292)
# УДАЛИТЬ эти строки:

    # Record realized PnL                          ← УДАЛИТЬ
    regime = self._current_regime.get(...)          ← УДАЛИТЬ  
    self._accounting.record_realized_pnl(...)       ← УДАЛИТЬ

# Оставить только update_position_price, расчёт realized_pnl 
# для записи в position, и публикацию POSITION_CLOSED.
```

**Проверка:** После фикса запустить на testnet, открыть и закрыть позицию. В логах `record_realized_pnl` должен появиться ОДИН раз, не два.

---

### FIX-002: PaperBroker fallback (BUG-002)
**Приоритет:** P0 — СЕЙЧАС
**Время:** 10 минут
**Файл:** `src/hean/execution/router.py`

**Решение:** Стартовать paper_broker ВСЕГДА (как safety net), не только при dry_run.

```python
# Файл: router.py, функция start() (~строка 176)
# БЫЛО:
if settings.dry_run:
    await self._paper_broker.start()

# СТАЛО:
# Always start paper broker as safety net (fallback if Bybit fails)
await self._paper_broker.start()
```

---

### FIX-003: Хардкод $50,000 (BUG-003)
**Приоритет:** P0 — СЕЙЧАС
**Время:** 30 минут
**Файлы:** Все файлы с `50000.0 if`

**Решение A (быстрый):** Заменить fallback на `None` и блокировать сигнал если цена неизвестна.

В `income/streams.py` — каждый stream:
```python
# БЫЛО:
price = ctx.get("price") or (50000.0 if "BTC" in symbol else 3000.0)

# СТАЛО:
price = ctx.get("price")
if price is None or price <= 0:
    logger.warning(f"Stream {self.stream_id}: no price for {symbol}, skipping signal")
    return
```

В `execution/router.py:615-619`:
```python
# БЫЛО:
best_bid = 50000.0 if "BTC" in symbol else 3000.0

# СТАЛО:
logger.error(f"No price data for {symbol}, rejecting order")
await self._publish_order_rejected(order_request, f"No price data for {symbol}")
return
```

---

### FIX-004: SyntheticFeed killswitch (BUG-004)
**Приоритет:** P0 — СЕЙЧАС
**Время:** 20 минут
**Файл:** `src/hean/main.py`

**Решение:** При fallback на SyntheticFeed — активировать killswitch.

```python
# Файл: main.py (~строка 649)
# БЫЛО:
except Exception as e:
    logger.warning(f"MARKET_STREAM_FALLBACK: ...")
    self._price_feed = SyntheticPriceFeed(self._bus, symbols)
    await self._price_feed.start()

# СТАЛО:
except Exception as e:
    logger.critical(f"MARKET_STREAM_FAILURE: Bybit feed failed: {e}")
    logger.critical("ACTIVATING KILLSWITCH: Cannot trade without real market data")
    self._stop_trading = True
    await self._bus.publish(Event(
        event_type=EventType.KILLSWITCH_TRIGGERED,
        data={"reason": f"Market data feed failed: {e}"}
    ))
    # Start synthetic feed ONLY for UI/monitoring (not for trading)
    self._price_feed = SyntheticPriceFeed(self._bus, symbols)
    await self._price_feed.start()
```

---

### FIX-005: filled_order_ids set (BUG-005)
**Приоритет:** P1
**Время:** 5 минут
**Файл:** `src/hean/main.py`

**Решение:** Использовать OrderedDict или deque вместо set.

```python
# БЫЛО:
if not hasattr(self, "_filled_order_ids"):
    self._filled_order_ids: set[str] = set()

# СТАЛО (в __init__):
from collections import OrderedDict
self._filled_order_ids: OrderedDict[str, bool] = OrderedDict()

# И далее:
if raw_order_id and raw_order_id in self._filled_order_ids:
    return
if raw_order_id:
    self._filled_order_ids[raw_order_id] = True
    # Keep bounded - remove oldest entries
    while len(self._filled_order_ids) > 5000:
        self._filled_order_ids.popitem(last=False)
```

---

### FIX-006: Нет реального закрытия на Bybit (BUG-006)
**Приоритет:** P0 — КРИТИЧНО
**Время:** 1 час
**Файл:** `src/hean/main.py`

**Решение:** `_close_position_at_price` должен отправлять ордер на закрытие через Bybit.

```python
async def _close_position_at_price(self, position, close_price, reason="forced_exit"):
    """Close a position at a specific price."""
    # 1. Отправить ордер на закрытие на биржу
    if (not settings.dry_run and settings.is_live 
        and hasattr(self, '_execution_router') 
        and self._execution_router._bybit_http):
        try:
            close_side = "sell" if position.side == "long" else "buy"
            close_request = OrderRequest(
                signal_id=f"close_{position.position_id}",
                strategy_id=position.strategy_id,
                symbol=position.symbol,
                side=close_side,
                size=position.size,
                price=None,  # market order
                order_type="market",
                metadata={"close_reason": reason, "position_id": position.position_id},
            )
            await self._execution_router._bybit_http.place_order(close_request)
            logger.info(f"Close order sent to Bybit: {position.symbol} {close_side} {position.size}")
        except Exception as e:
            logger.error(f"CRITICAL: Failed to close position on Bybit: {e}")
            # НЕ удаляем из internal accounting — позиция ещё открыта на бирже!
            return
    
    # 2. Обновить internal accounting
    self._accounting.update_position_price(position.position_id, close_price)
    
    if position.side == "long":
        realized_pnl = (close_price - position.entry_price) * position.size
    else:
        realized_pnl = (position.entry_price - close_price) * position.size
    
    position.current_price = close_price
    position.realized_pnl = realized_pnl
    
    # 3. Публикуем POSITION_CLOSED (PnL запишется в _handle_position_closed)
    await self._bus.publish(Event(
        event_type=EventType.POSITION_CLOSED,
        data={"position": position, "close_reason": reason},
    ))
```

---

## НЕДЕЛЯ 2: Серьёзные проблемы (торговля работает, но неэффективна)

---

### FIX-007: Income Streams — подключить данные или отключить
**Приоритет:** P2
**Время:** 30 минут (отключить) / 2-3 дня (подключить)

**Вариант A — Быстрый (отключить мёртвое):**

Добавить в `.env`:
```
STREAM_FUNDING_ENABLED=true    # Единственный с реальными данными
STREAM_MAKER_REBATE_ENABLED=false
STREAM_BASIS_ENABLED=false
STREAM_VOLATILITY_ENABLED=false
```

**Вариант B — Правильный (подключить данные):**

В PhysicsEngine или RegimeDetector добавить публикацию CONTEXT_UPDATE с полями `regime`, `vol_short`, `vol_long`, `mean_price`:

```python
# В regime_detector.py, после расчёта нового режима:
await self._bus.publish(Event(
    event_type=EventType.CONTEXT_UPDATE,
    data={
        "context_type": "market_state",
        "symbol": symbol,
        "regime": current_regime,
        "price": current_price,
        "vol_short": short_term_volatility,
        "vol_long": long_term_volatility,
        "mean_price": rolling_mean_price,
    }
))
```

---

### FIX-008: RiskLimits — добавить cooldown для всех стратегий
**Приоритет:** P2
**Время:** 30 минут
**Файл:** `src/hean/risk/limits.py`

```python
def check_cooldown(self, strategy_id: str) -> tuple[bool, str]:
    if settings.debug_mode:
        return True, ""
    
    # Универсальный cooldown для всех стратегий
    cooldown_map = {
        "impulse_engine": settings.impulse_cooldown_after_losses,
        "hf_scalping": 2,     # 2 подряд проигрыша
        "momentum_trader": 3,  # 3 подряд проигрыша
        "paper_assist_micro": 5,
    }
    
    threshold = cooldown_map.get(strategy_id, 3)  # default: 3
    
    if self._consecutive_losses[strategy_id] >= threshold:
        return False, f"Cooldown: {threshold} consecutive losses for {strategy_id}"
    
    return True, ""
```

Аналогично для `check_daily_attempts` — добавить лимиты для каждой стратегии.

---

### FIX-009: Brain → подключить к стратегиям
**Приоритет:** P2
**Время:** 2-4 часа
**Файлы:** `brain/claude_client.py`, `strategies/impulse_engine.py`

**Шаг 1:** Brain публикует анализ на EventBus:
```python
# В claude_client.py, после analysis:
if analysis:
    await self._bus.publish(Event(
        event_type=EventType.BRAIN_ANALYSIS,
        data={
            "symbol": symbol,
            "sentiment": analysis.overall_sentiment,  # bullish/bearish/neutral
            "confidence": analysis.confidence,
            "forces": [f.to_dict() for f in analysis.forces],
            "signals": [s.to_dict() for s in analysis.signals],
        }
    ))
```

**Шаг 2:** ImpulseEngine подписывается:
```python
# В impulse_engine.py:
self._brain_sentiment: dict[str, str] = {}
self._bus.subscribe(EventType.BRAIN_ANALYSIS, self._handle_brain)

async def _handle_brain(self, event):
    data = event.data
    self._brain_sentiment[data["symbol"]] = data["sentiment"]

# В логике генерации сигнала:
brain = self._brain_sentiment.get(symbol, "neutral")
if brain == "bearish" and signal_side == "buy":
    # Снизить confidence или размер
    signal.metadata["brain_conflict"] = True
    signal.metadata["size_multiplier"] = 0.5
```

---

### FIX-010: Position Reconciliation
**Приоритет:** P2
**Время:** 3-4 часа
**Файл:** Новый файл `src/hean/risk/reconciliation.py`

```python
class PositionReconciler:
    """Периодическая проверка: позиции HEAN == позиции Bybit."""
    
    def __init__(self, bus, accounting, bybit_http):
        self._bus = bus
        self._accounting = accounting
        self._bybit_http = bybit_http
    
    async def reconcile(self):
        """Сравнить internal positions с биржевыми."""
        # 1. Получить позиции с Bybit
        bybit_positions = await self._bybit_http.get_positions()
        
        # 2. Получить internal positions
        internal_positions = {
            p.symbol: p for p in self._accounting.get_positions()
        }
        
        # 3. Найти расхождения
        for bp in bybit_positions:
            if bp.symbol not in internal_positions:
                logger.critical(f"ORPHAN ON EXCHANGE: {bp.symbol} {bp.size} not in internal accounting!")
                # Либо закрыть на бирже, либо добавить в accounting
        
        for symbol, ip in internal_positions.items():
            if symbol not in {bp.symbol for bp in bybit_positions}:
                logger.critical(f"PHANTOM INTERNAL: {symbol} {ip.size} not on exchange!")
                # Удалить из internal accounting
```

Запускать каждые 60 секунд через `_clock.schedule_periodic`.

---

### FIX-011: ANTHROPIC_API_KEY
**Приоритет:** P2
**Время:** 5 минут

```bash
# .env:
ANTHROPIC_API_KEY=sk-ant-api03-...
```

Без ключа Brain работает на rule-based (5 строк if/else). С ключом — полноценный анализ рынка через Claude.

---

## НЕДЕЛЯ 3-4: Оптимизация и расширение

---

### FIX-012: Обучить TCN
**Приоритет:** P3
**Время:** 1-2 дня

1. Собрать данные: записывать тики в DuckDB (уже подключен) неделю
2. Создать train script:
```python
# scripts/train_tcn.py
import torch
from hean.core.intelligence.tcn_predictor import TCPriceReversalPredictor

# Загрузить данные
ticks = load_from_duckdb("SELECT * FROM ticks ORDER BY timestamp")

# Подготовить sequences
X, y = prepare_sequences(ticks, sequence_length=10000)

# Train
model = TCPriceReversalPredictor(sequence_length=10000)
optimizer = torch.optim.Adam(model.model.parameters(), lr=0.001)

for epoch in range(100):
    for batch_X, batch_y in DataLoader(X, y, batch_size=32):
        pred = model.model(batch_X)
        loss = F.binary_cross_entropy(pred, batch_y)
        loss.backward()
        optimizer.step()

# Save
torch.save(model.model.state_dict(), "models/tcn_v1.pt")
```

3. Загрузить в OracleEngine при старте:
```python
self.tcn_predictor.model.load_state_dict(torch.load("models/tcn_v1.pt"))
```

---

### FIX-013: Скомпилировать C++ модули
**Приоритет:** P3
**Время:** 2-4 часа

```bash
cd src/hean/core/cpp
mkdir build && cd build
cmake .. -DPYTHON_EXECUTABLE=$(which python3)
make -j4
# Результат: graph_engine_py.so
cp graph_engine_py.so /path/to/python/site-packages/
```

Разблокирует:
- Algorithmic Fingerprinting в OracleEngine
- FastWarden (TDA) в SmartLimitExecutor
- Meta-Learning C++ weight parsing

---

### FIX-014: iOS — заменить Mock на Live
**Приоритет:** P3
**Время:** 1 неделя

1. API сервер уже есть (`apps/ui/` + FastAPI backend)
2. Реализовать `Services/Live/LiveMarketService.swift`:
```swift
class LiveMarketService: MarketServiceProtocol {
    private let ws: WebSocketManager
    
    func connect() {
        ws.connect(url: "ws://\(config.apiHost)/ws/market")
    }
    
    func subscribe(symbol: String) {
        ws.send(["action": "subscribe", "symbol": symbol])
    }
}
```

3. В `ServiceContainer` переключить Mock → Live:
```swift
// БЫЛО:
container.register(MockMarketService() as MarketServiceProtocol)
// СТАЛО:
container.register(LiveMarketService(config: appConfig) as MarketServiceProtocol)
```

---

### FIX-015: Symbiont X — решить судьбу
**Приоритет:** P4
**Время:** 30 минут (удалить) / 2 недели (интегрировать)

**Вариант A:** Удалить. Сэкономит путаницу и размер проекта.
**Вариант B:** Интегрировать GenomeLab для эволюции стратегий и ImmuneSystem для circuit breakers в основной EventBus.

---

### FIX-016: Graceful Shutdown
**Приоритет:** P2
**Время:** 30 минут
**Файл:** `src/hean/__main__.py` или точка входа

```python
import signal

def handle_shutdown(signum, frame):
    logger.critical(f"Received signal {signum}, initiating graceful shutdown")
    asyncio.create_task(trading_system.panic_close_all("signal_shutdown"))
    asyncio.create_task(trading_system.stop())

signal.signal(signal.SIGTERM, handle_shutdown)
signal.signal(signal.SIGINT, handle_shutdown)
```

---

## ЧЕКЛИСТ ПЕРЕД ЗАПУСКОМ НА РЕАЛЬНЫЕ ДЕНЬГИ

- [ ] FIX-001: Двойной PnL исправлен
- [ ] FIX-002: PaperBroker всегда стартует
- [ ] FIX-003: Нет хардкодов $50,000
- [ ] FIX-004: SyntheticFeed = killswitch
- [ ] FIX-005: filled_order_ids упорядочен
- [ ] FIX-006: Ордер на закрытие отправляется на Bybit
- [ ] FIX-008: Cooldown для всех стратегий
- [ ] FIX-010: Position reconciliation работает
- [ ] FIX-016: Graceful shutdown настроен
- [ ] Прогнать на testnet 24 часа без ошибок в логах
- [ ] Проверить equity на testnet совпадает с балансом на Bybit
- [ ] Проверить что позиции на Bybit = позиции в HEAN
