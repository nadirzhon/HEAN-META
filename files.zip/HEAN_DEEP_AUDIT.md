# HEAN — Глубокий аудит проекта

## КРИТИЧЕСКИЕ БАГИ (могут потерять деньги)

---

### 🔴 BUG-001: Двойной учёт PnL
**Файлы:** `main.py:1694` и `main.py:2310`

`record_realized_pnl()` вызывается **дважды** при каждом закрытии позиции:
1. В `_close_position_at_price()` (строка 2310) — считает PnL и вызывает `record_realized_pnl`
2. В `_handle_position_closed()` (строка 1694) — получает событие POSITION_CLOSED и снова вызывает `record_realized_pnl`

А `_close_position_at_price` в конце публикует `POSITION_CLOSED`, что триггерит `_handle_position_closed`.

**Результат:** Каждая прибыльная сделка записывается как 2x прибыль. Каждая убыточная — как 2x убыток. Equity, cash, strategy metrics — все искажены.

**Цепная реакция:**
- Kelly Criterion получает искажённый profit factor → неправильный размер позиций
- SmartReinvestor реинвестирует 2x прибыли → раздутый equity
- DepositProtector видит неправильный equity → может пропустить опасную ситуацию или заблокировать безопасную торговлю
- Decision Memory записывает 2x PnL → неправильные context penalties

---

### 🔴 BUG-002: PaperBroker не стартует при Bybit fallback
**Файл:** `execution/router.py:176-203`

```python
# paper_broker.start() вызывается ТОЛЬКО если dry_run=True
if settings.dry_run:
    await self._paper_broker.start()

# Но если Bybit не подключается, _bybit_http = None
# и ордера идут в paper_broker который НЕ ЗАПУЩЕН
```

**Когда:** Bybit WS/HTTP падает → `_bybit_http = None` → ордера роутятся в `_paper_broker.submit_order()` → paper broker не подписан на тики → ордера никогда не заполняются → зависают навечно.

---

### 🔴 BUG-003: SyntheticFeed с хардкодом $50,000 BTC
**Файлы:** `exchange/synthetic_feed.py`, `income/streams.py`, `execution/router.py:618`, `api/routers/trading.py:276`

По всему проекту разбросаны хардкоды:
```python
price = 50000.0 if "BTC" in symbol else 3000.0
```

В income streams это используется как **entry_price для реальных сигналов**:
- `FundingHarvesterStream` (строка ~207): если `ctx.get("price")` is None → $50,000
- `MakerRebateStream` (строка ~252): если `ctx.get("price")` is None → $50,000
- `BasisHedgeStream` (строка ~299): если `ctx.get("price")` is None → $50,000

BTC сейчас торгуется ~$97,000+. Ордер по $50,000 при реальной цене $97,000 — это мгновенный убыток 48% для long или мгновенная прибыль 48% для short.

В `execution/router.py:618`:
```python
# Final fallback
best_bid = 50000.0 if "BTC" in symbol else 3000.0
```
Это может создать РЕАЛЬНЫЙ ордер на Bybit по $50,000 вместо рыночной цены.

**Масштаб:** Для 6 символов (BTCUSDT, ETHUSDT, SOLUSDT, BNBUSDT, XRPUSDT, ADAUSDT) — только BTC и ETH имеют хоть какой-то fallback. SOL/BNB/XRP/ADA вообще попадут в BTC branch по else.

---

### 🔴 BUG-004: Тихий переход на SyntheticFeed
**Файл:** `main.py:649-657`

```python
except Exception as e:
    logger.warning(f"MARKET_STREAM_FALLBACK: ...")
    self._price_feed = SyntheticPriceFeed(self._bus, symbols)
    await self._price_feed.start()
```

Если Bybit WS падает → система тихо переключается на фейковые случайные цены. При этом:
- Стратегии продолжают генерить сигналы по фейковым данным
- Если Bybit HTTP работает → реальные ордера на бирже по фейковым ценам
- Нет никакого alert/killswitch при переключении на synthetic

---

### 🔴 BUG-005: `_filled_order_ids` set растёт и подрезается неправильно
**Файл:** `main.py:1562-1567`

```python
if len(self._filled_order_ids) > 5000:
    self._filled_order_ids = set(list(self._filled_order_ids)[-2500:])
```

`set` — неупорядоченная коллекция. `list(set)[-2500:]` берёт случайные 2500 элементов, не последние. Старые order_id могут остаться, а новые быть удалены → повторные fill для недавних ордеров не будут отфильтрованы.

---

### 🔴 BUG-006: Нет закрытия позиций на Bybit
**Файл:** `main.py:2292-2323` (`_close_position_at_price`)

Функция `_close_position_at_price` просто обновляет внутренний accounting и публикует POSITION_CLOSED. **Она не отправляет ордер на закрытие на Bybit!**

Для paper broker это ОК. Для live Bybit — позиция остаётся открытой на бирже, хотя в системе она «закрыта».

---

## СЕРЬЁЗНЫЕ ПРОБЛЕМЫ (не потеряешь, но не заработаешь)

---

### 🟠 PROB-001: Income Streams — все заглушки
**Файл:** `income/streams.py`

Все 4 income streams зависят от `CONTEXT_UPDATE` с определёнными полями:
- `FundingHarvesterStream` → ожидает `funding_rate` (получает от BybitPriceFeed? нужно проверить)
- `MakerRebateStream` → ожидает `regime` в CONTEXT_UPDATE (кто публикует?)
- `BasisHedgeStream` → ожидает `basis` (никто не публикует этот ключ)
- `VolatilityHarvestStream` → ожидает `vol_short`, `vol_long`, `mean_price` (никто не публикует)

**Результат:** 3 из 4 streams получают NULL данные и никогда не генерируют сигналы. Это мёртвый код.

---

### 🟠 PROB-002: TCN нейросеть не обучена
**Файл:** `core/intelligence/tcn_predictor.py`

PyTorch модель инициализируется с `random weights` (стандартный `weight.data.normal_(0, 0.01)`). Нет загрузки чекпоинта, нет train loop. Предсказания = случайный шум.

ImpulseEngine использует TCN через OracleEngine:
```python
tcn_result = self.tcn_predictor.get_prediction_with_confidence()
```
И принимает торговые решения на основе random output.

---

### 🟠 PROB-003: C++ модули не скомпилированы
**Файлы:** `core/intelligence/oracle_engine.py`, `exchange/executor.py`

`graph_engine_py` — C++ модуль для:
- Algorithmic Fingerprinting (распознавание паттернов маркет-мейкеров)
- FastWarden / TDA (Topological Data Analysis для предсказания slippage)

Без него:
- Oracle Engine работает только на TCN (который не обучен — см. PROB-002)
- SmartLimitExecutor использует fallback curvature (менее точный)

---

### 🟠 PROB-004: Brain (Claude AI) не влияет на торговлю
**Файл:** `brain/claude_client.py`

Brain анализирует рынок и публикует результаты в deque (внутренний буфер). Но:
1. `ANTHROPIC_API_KEY` пуст → rule-based fallback (простые if/else)
2. Результаты **не публикуются на EventBus** как событие, которое бы слушали стратегии
3. Ни одна стратегия не подписана на Brain output

Brain — read-only dashboard компонент. Он анализирует, но ни на что не влияет.

---

### 🟠 PROB-005: Multimodal Swarm — чистая заглушка
**Файл:** `core/intelligence/multimodal_swarm.py`

MultimodalTensor имеет 4 модальности:
- `price_features` → заполняются из тиков ✅
- `sentiment_features` → **всегда нули** (нет Twitter/Reddit/News API)
- `onchain_features` → **всегда нули** (нет Glassnode/IntoTheBlock API)
- `macro_features` → **всегда нули** (нет DXY/SPX/bond yield feed)

75% данных = нули. Swarm принимает решения на основе одних тиков, маскируясь под «мультимодальный анализ».

---

### 🟠 PROB-006: Causal Inference без кросс-биржевых данных
**Файл:** `core/intelligence/causal_inference_engine.py`

`source_symbols` включают SPX, NDX, DXY — но данные по ним не поступают. Реально работает только между криптопарами на Bybit (BTC→ETH, BTC→SOL, etc.). Granger causality между парами одной биржи с одним маркетмейкером — гарантированно высокая, но не дающая trading edge.

---

### 🟠 PROB-007: RiskLimits — cooldown только для impulse_engine
**Файл:** `risk/limits.py:148-176`

```python
def check_cooldown(self, strategy_id: str) -> tuple[bool, str]:
    if strategy_id == "impulse_engine":
        # ... cooldown logic
    # Для ВСЕХ остальных стратегий: pass → return True
```

Остальные стратегии (HFScalping, MomentumTrader, etc.) не имеют cooldown. При серии убытков они продолжат торговать без ограничений.

Аналогично `check_daily_attempts` — лимит только для impulse_engine.

---

### 🟠 PROB-008: Symbiont X — параллельная вселенная
**Директория:** `src/hean/symbiont_x/`

Полноценная альтернативная система с:
- Своими WS коннекторами (не используют EventBus)
- Своим CapitalAllocator
- Своим RegimeBrain
- Своим BacktestEngine
- Genome Lab (эволюция стратегий)
- Immune System (circuit breakers)

**Полностью отключена от main.py.** Не импортируется, не запускается. ~3000+ строк мёртвого кода.

---

### 🟠 PROB-009: Position reconciliation — нет
Нет механизма синхронизации позиций между HEAN (internal accounting) и Bybit (биржевые позиции).

Если HEAN считает позицию закрытой, а на Bybit она открыта (BUG-006), или наоборот — нет способа узнать и исправить.

---

### 🟠 PROB-010: iOS App — полностью на Mock данных
**Директория:** `ios/HEAN/Mock/`

12 Mock-файлов подставляют фейковые данные для всех 20+ экранов. `Services/Live/` — пусто или минимально. WebSocket клиент есть, но сервер API не поставляет данные в нужном формате.

---

## СРЕДНЕПРИОРИТЕТНЫЕ ПРОБЛЕМЫ

### 🟡 MID-001: SmartReinvestor без лимитов
**Файл:** `main.py:1735-1758`

После каждой прибыльной сделки вызывается SmartReinvestor, который добавляет `reinvest_amount` к cash. В сочетании с BUG-001 (двойной PnL), equity раздувается экспоненциально.

### 🟡 MID-002: Memory leak в deque'ах
Множество `deque(maxlen=N)` по всему проекту. Они ограничены, но их десятки — каждая стратегия, каждый компонент хранит историю. При 6 символах × тики каждые 100мс × 24 часа — суммарное потребление памяти может расти.

### 🟡 MID-003: Нет graceful shutdown при SIGTERM
Если процесс убивается, открытые позиции на Bybit остаются. Нет обработки SIGTERM/SIGINT для корректного закрытия.

### 🟡 MID-004: SOLUSDT, BNBUSDT, XRPUSDT, ADAUSDT — нет fallback prices
Хардкоды $50,000/$3,000 покрывают только BTC/ETH. Для остальных 4 символов условие `"BTC" in symbol` ложно → все попадают в `else 3000.0` ($3000 для SOL/BNB/XRP/ADA — бессмысленно).

### 🟡 MID-005: Paper Trade Assist — random trading
`_micro_trade_fallback_loop` генерирует сигналы со случайным направлением и случайным символом каждые N секунд. Это не торговля — это генератор шума для тестирования UI. Но если включить на live — будет торговать рандомно.

### 🟡 MID-006: Execution Smoke Test — не найден
Config упоминает `execution_smoke_test_enabled`, но фактическая реализация smoke test при старте не обнаружена.

### 🟡 MID-007: Нет проверки баланса перед ордером
Система рассчитывает размер позиции от equity, но не проверяет реальный доступный баланс на Bybit перед отправкой ордера. Если equity в accounting расходится с реальным балансом (BUG-001), ордера будут отклоняться биржей.

---

## МЁРТВЫЙ КОД (можно безопасно удалить)

| Модуль | Размер | Причина |
|--------|--------|---------|
| `symbiont_x/` (весь) | ~3000+ строк | Не подключен к main.py |
| `strategies/sentiment_strategy.py` | ~200 строк | Не импортируется |
| `strategies/correlation_arb.py` | ~300 строк | В __init__, не в main.py |
| `strategies/inventory_neutral_mm.py` | ~300 строк | В __init__, не в main.py |
| `strategies/rebate_farmer.py` | ~200 строк | В __init__, не в main.py |
| `income/streams.py` (3 из 4) | ~200 строк | Нет поставщиков данных |
| Multimodal Swarm (75%) | ~400 строк | Sentiment/onchain/macro = нули |

---

## ПОЗИТИВ (что реально хорошо)

1. **ImpulseEngine** — продвинутая стратегия, хорошо структурированная
2. **EventBus архитектура** — чистый pub/sub, легко расширять
3. **Risk management каркас** — DepositProtector, KillSwitch, MultiLevelProtection
4. **Idempotency в ExecutionRouter** — предотвращает дубликаты ордеров
5. **Telemetry/Observability** — ORDER_DECISION, NoTradeReport дают хорошую диагностику
6. **Adaptive parameters** — TTL и offset подстраиваются под рынок
7. **Physics Engine** — оригинальная идея с корректной реализацией математики
